package com.example.cloudproject

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
